<?
// ################################
// #                                                             
// #  ======== Programming By supervirus ===========  
// #
// #    The Scripet Progeramed By super virus 
// #
// #  Copyright � 2011 super virus . All Rights Reserved. 
// #
// #  If you want any support vist this site.           
// #      https://www.facebook.com/l0ldz 
// #
// ################################
echo '<p align="center" ><h1><br /><center> This Page Ne Existe Pas By  https://www.facebook.com/l0ldz  !! </center></h1></p>';


?>