<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style addthis_32x32_style">
<a class="addthis_button_preferred_1"></a>
<a class="addthis_button_preferred_2"></a>
<a class="addthis_button_preferred_3"></a>
<a class="addthis_button_preferred_4"></a>
<a class="addthis_button_compact"></a>
<a class="addthis_counter addthis_bubble_style"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=ra-4e5ba21548313a4f"></script>
<!-- AddThis Button END -->
<?
// ################################
// #                                                             
// #  ======== Programming By Mr Alibdaer ===========  
// #
// #    The Scripet Progeramed By Alibdaer And Mr Alibdaer
// #
// #  Copyright � 2011 Mr Alibdaer. All Rights Reserved. 
// #
// #  If you want any support vist this site.           
// #           Alibdaer 
// #
// ################################
echo '	<tr>
		<td colspan="3">
			<div class="head_panel">copyright</div>	
				<div align="center" class="body_panel">
					Copyright : 2012 - 2013 | AiMAD</a> 
					<br /> programmed by super virus
				</div>
		</td>
	</tr>
</table>
</body>
</html>';
?>