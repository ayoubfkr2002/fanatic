<?
echo '	<div class="head_panel">Testing Page</div>	
				<div class="body_panel">
			Testing Page
				</div>';
?>