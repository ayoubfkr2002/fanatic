<?
/* -------------------------------------*\
|  All Right Reserved                    |
|  The Scripet Progeramed By  Th3 Basmir |
|  Email : Master-Basmir@Hotmail.fr      |
|  All Right Resirved For Him. 			 |
|  Programed By Th3 Basmir.				 |
|  My Name : Samir El Baz                |
\*______________________________________*/
header("Location: ../index.php");
?>